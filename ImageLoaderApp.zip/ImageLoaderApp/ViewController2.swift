//
//  ViewController.swift
//  ImageLoaderApp
//
//  Created by Dusan Mitrasinovic on 8/21/16.
//  Copyright © 2016 Dusan Mitrasinovic. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    
    
    
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var image1: UIImageView!
    
    
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var txtConent: UITextView!
    
    
    @IBAction func backAction(sender: AnyObject) {
        
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Image Loader"
        
        let url = NSURL(string: "https://timedotcom.files.wordpress.com/2016/08/no-mans-sky-4k-geforce-com-pc-screenshot-001.jpg?w=560&h=315")
        let data = NSData(contentsOfURL: url!) //make sure your image in this url does exist, otherwise unwrap in a if let check
        image1.image = UIImage(data: data!)
        
        parseJson()
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func parseJson () {
        
        let url = NSURL(string: "https://raw.githubusercontent.com/marsicdev/fci-mobile/master/fci-mobile-challenge-api.json")
        
        
        
        let task = NSURLSession.sharedSession().dataTaskWithURL(url!) { (data, response, error) -> Void in dispatch_async(dispatch_get_main_queue(), {
            
            // NSLog("Log", "Log log")
            // self.setTableArray(data!)
            self.setData(data!)
            
            
            
            //            let jsonObject : AnyObject! = NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions.MutableContainers, error: nil)
            
            //  let statusesArray = jsonObject as? NSArray
            
        })
            
        }
        task.resume()
    }
    
    func setData (weathersData: NSData) {
        
        let jsonResults :  NSArray!
        
        do {
            jsonResults = try NSJSONSerialization.JSONObjectWithData(weathersData, options: []) as! NSArray
            
            print(jsonResults)
            
            //[String : AnyObject]
            // success ...
            
            if (jsonResults != nil) {
                
                
                
                let title = jsonResults![1] ["title"] as! String
                let content = jsonResults[1]["content"] as! String
                
                //  NSLog("", naslov)
                print(title)
                titleLbl.text = title
                txtConent.text = content
                
                
                //                timeLabel.text = prepTime+" min"
                
                
                
                
            }
            
            
            
        } catch let error as NSError {
            // failure
            print("Fetch failed: \(error.localizedDescription)")
        }
    }
    
    //    func setData (weathersData: NSData) {
    //
    //        let jsonResults : Array<AnyObject>
    //
    //        do {
    //            jsonResults = try NSJSONSerialization.JSONObjectWithData(weathersData, options: []) as! Array<AnyObject>
    //
    //            // print(jsonResults)
    //
    //            //[String : AnyObject]
    //            // success ...
    //
    //           if ((jsonResults as? Array<AnyObject>) != nil) {
    //
    //
    //
    //                let naslov = jsonResults["title"] as!
    //             //   let prepTime = jsonResults["recipes"]![0]["preparation_time"] as! String
    //
    //
    //                //                recipeLabel.text = naslov
    //                //                timeLabel.text = prepTime+" min"
    //
    //                titleLbl.text = naslov
    //
    //
    //                print(naslov)
    //
    //
    //
    //
    //           }
    //
    //
    //
    //        } catch let error as NSError {
    //            // failure
    //            print("Fetch failed: \(error.localizedDescription)")
    //        }
    //    }
    
    
}

