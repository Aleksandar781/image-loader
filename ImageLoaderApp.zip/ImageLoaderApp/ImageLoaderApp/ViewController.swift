//
//  ViewController.swift
//  ImageLoaderApp
//
//  Created by Dusan Mitrasinovic on 8/21/16.
//  Copyright © 2016 Dusan Mitrasinovic. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var image1: UIImageView!
    
    @IBOutlet weak var image2: UIImageView!
    
    @IBOutlet weak var image3: UIImageView!
    
    @IBOutlet weak var image4: UIImageView!
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Image Loader"
        
        let url = NSURL(string: "https://timedotcom.files.wordpress.com/2016/08/no-mans-sky-4k-geforce-com-pc-screenshot-002.png?w=560&h=315")
        let data = NSData(contentsOfURL: url!) //make sure your image in this url does exist, otherwise unwrap in a if let check
        image1.image = UIImage(data: data!)
        
        
        let url1 = NSURL(string: "https://timedotcom.files.wordpress.com/2016/08/no-mans-sky-4k-geforce-com-pc-screenshot-001.jpg?w=560&h=315")
        let data1 = NSData(contentsOfURL: url1!) //make sure your image in this url does exist, otherwise unwrap in a if let check
        image2.image = UIImage(data: data1!)
        
        
        let url2 = NSURL(string: "https://timedotcom.files.wordpress.com/2016/07/gettyimages-163292239.jpg?w=560&h=315")
        let data2 = NSData(contentsOfURL: url2!) //make sure your image in this url does exist, otherwise unwrap in a if let check
        image3.image = UIImage(data: data2!)
        
        let url3 = NSURL(string: "https://timedotcom.files.wordpress.com/2015/01/money-dollar-bills-3.jpg?w=560&h=315")
        let data3 = NSData(contentsOfURL: url3!) //make sure your image in this url does exist, otherwise unwrap in a if let check
        image4.image = UIImage(data: data3!)
        // Do any additional setup after loading the view, typically from a nib.
        
        
        let tapGestureRecognizer = UITapGestureRecognizer(target:self, action:Selector("image1Tapped:"))
        image1.userInteractionEnabled = true
        image1.addGestureRecognizer(tapGestureRecognizer)
        
        let tapGestureRecognizer1 = UITapGestureRecognizer(target:self, action:Selector("image2Tapped:"))
        image2.userInteractionEnabled = true
        image2.addGestureRecognizer(tapGestureRecognizer1)
        
        let tapGestureRecognizer2 = UITapGestureRecognizer(target:self, action:Selector("image3Tapped:"))
        image3.userInteractionEnabled = true
        image3.addGestureRecognizer(tapGestureRecognizer2)
        
        let tapGestureRecognizer3 = UITapGestureRecognizer(target:self, action:Selector("image4Tapped:"))
        image4.userInteractionEnabled = true
        image4.addGestureRecognizer(tapGestureRecognizer3)
        
    }
    
    func image1Tapped(img: AnyObject)
    {
        let firstViewController:ViewController1 = ViewController1()
        
        self.presentViewController(firstViewController, animated: true, completion: nil)
    }
    
    func image2Tapped(img: AnyObject)
    {
        let firstViewController:ViewController2 = ViewController2()
        
        self.presentViewController(firstViewController, animated: true, completion: nil)
    }
    
    func image3Tapped(img: AnyObject)
    {
        let firstViewController:ViewController3 = ViewController3()
        
        self.presentViewController(firstViewController, animated: true, completion: nil)
    }
    func image4Tapped(img: AnyObject)
    {
        let firstViewController:ViewController4 = ViewController4()
        
        self.presentViewController(firstViewController, animated: true, completion: nil)
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func parseJson () {
        
        let url = NSURL(string: "https://timedotcom.files.wordpress.com/2016/08/no-mans-sky-4k-geforce-com-pc-screenshot-002.png?w=560&h=315")
        
        
        
        let task = NSURLSession.sharedSession().dataTaskWithURL(url!) { (data, response, error) -> Void in dispatch_async(dispatch_get_main_queue(), {
            
            // NSLog("Log", "Log log")
            // self.setTableArray(data!)
            self.setData(data!)
            
            
            
            //            let jsonObject : AnyObject! = NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions.MutableContainers, error: nil)
            
            //  let statusesArray = jsonObject as? NSArray
            
        })
            
        }
        task.resume()
    }
    
    
    
    func setData (weathersData: NSData) {
        
        let jsonResults : [String : AnyObject]
        
        do {
            jsonResults = try NSJSONSerialization.JSONObjectWithData(weathersData, options: []) as! [String : AnyObject]
            
            // print(jsonResults)
            
            //[String : AnyObject]
            // success ...
            
            if ((jsonResults["recipes"] as? NSArray) != nil) {
                
                
                
                let naslov = jsonResults["title"] as! String
                let prepTime = jsonResults["recipes"]![0]["preparation_time"] as! String
                
                
//                recipeLabel.text = naslov
//                timeLabel.text = prepTime+" min"
                
                print(naslov)
                
                
                
                
            }
            
            
            
        } catch let error as NSError {
            // failure
            print("Fetch failed: \(error.localizedDescription)")
        }
    }
    
    
    


}

